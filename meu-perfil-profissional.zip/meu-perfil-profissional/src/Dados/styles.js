import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  area: {
    marginTop: 10,
  },
  textoPrincipal: {
    fontSize: 20,
    color: '#FF0000',
  },
  alinhaTexto: {
    textAlign: 'center',
  },
});

export { styles };
