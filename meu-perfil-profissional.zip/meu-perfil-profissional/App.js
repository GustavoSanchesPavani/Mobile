import { View, Text,  } from 'react-native';
import Dados_Pessoais from './src/Dados/Index.js';
import Formacao from './src/Formacao/Index.js';
import Exp from './src/Experiencias/Index.js';
import Projetos from './src/projetos/Index.js';


function App() {

  return (
    <View>
      
      <Dados_Pessoais />
      <Formacao />
      <Exp />
      <Projetos />
      
    </View>
  );
}

export default App;
